//
//  ShowTableViewCell.m
//  CDMapViewDemo
//
//  Created by 邹少军 on 16/4/11.
//  Copyright © 2016年 cd. All rights reserved.
//

#import "ShowTableViewCell.h"
#import "UIView+SJFrame.h"

#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height


@interface ShowTableViewCell()
{
    UILabel *_title;//标题
    UILabel *_subTitle;//副标题
    UILabel *_lon;//经度
    UILabel *_lat;//纬度

}
@end

@implementation ShowTableViewCell

- (void)awakeFromNib {
    // Initialization code
}



- (void)reloadingPin:(REVClusterPin *)Pin
{
    
    
    if(_title == nil)
    {
        _title = [[UILabel alloc] init];
        _title.frame = CGRectMake(15, 5, kScreenWidth - 15, 20);
        _title.text = Pin.title;
        _title.font = [UIFont systemFontOfSize:16.0];
        _title.textColor = [UIColor blackColor];
        [self addSubview:_title];
    }
    
    
    if (_subTitle == nil) {
        
        _subTitle = [[UILabel alloc] init];
        _subTitle.frame = CGRectMake(15, _title.top + _title.height + 5, kScreenWidth - 15, 20);
        _subTitle.text = Pin.subtitle;
        _subTitle.font = [UIFont systemFontOfSize:14.0];
        _subTitle.textColor = [UIColor blackColor];
        [self addSubview:_subTitle];
    }

    
    if (_lon == nil) {
        _lon = [[UILabel alloc] init];
        _lon.frame = CGRectMake(15, _subTitle.top + _title.height + 5, kScreenWidth - 15, 20);
        _lon.text = [NSString stringWithFormat:@"%f",Pin.coordinate.longitude];
        _lon.font = [UIFont systemFontOfSize:14.0];
        _lon.textColor = [UIColor blackColor];
        [self addSubview:_lon];
    }
    
    
    if (_lat == nil) {
        _lat = [[UILabel alloc] init];
        _lat.frame = CGRectMake(15, _lon.top + _lon.height + 5, kScreenWidth - 15, 20);
        _lat.text = [NSString stringWithFormat:@"%f",Pin.coordinate.latitude];
        _lat.font = [UIFont systemFontOfSize:14.0];
        _lat.textColor = [UIColor blackColor];
        [self addSubview:_lat];
    }
    
    
    
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
