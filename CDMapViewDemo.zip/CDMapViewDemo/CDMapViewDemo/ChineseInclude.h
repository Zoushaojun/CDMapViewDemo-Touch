//
//  ChineseInclude.h
//  橙电
//
//  Created by 邹少军 on 15/9/30.
//  Copyright (c) 2015年 com.chengdian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ChineseInclude : NSObject

+ (BOOL)inIncludeChineseInString:(NSString *)str;

@end
