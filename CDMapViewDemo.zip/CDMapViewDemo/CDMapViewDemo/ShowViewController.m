//
//  ShowViewController.m
//  CDMapViewDemo
//
//  Created by 邹少军 on 16/4/11.
//  Copyright © 2016年 cd. All rights reserved.
//

#import "ShowViewController.h"
#import "ShowTableViewCell.h"
#import "REVClusterPin.h"
#import "ViewController.h"


#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height


@interface ShowViewController ()<UITableViewDataSource ,UITableViewDelegate>
{
    UITableView *_tableview;
    
    UILabel *lbl_subtitle;
}

@end

@implementation ShowViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSLog(@"datasource=%@",self.dataSource);
    

    
    
    if (_tableview == nil) {
        _tableview = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableview.dataSource = self;
        _tableview.delegate = self;
        [self.view addSubview:_tableview];
    }
   
    
    // Do any additional setup after loading the view.
    
}




-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataSource.count;
    
}

//返回每行cell的高度
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 110;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    
    REVClusterPin *pin = [self.dataSource objectAtIndex:indexPath.row];
    
    static NSString *cellIdentifier = @"Cell";
    ShowTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[ShowTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    [cell reloadingPin:pin];
    
    
    
    return cell;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
