//
//  ViewController.h
//  CDMapViewDemo
//
//  Created by 邹少军 on 15/10/21.
//  Copyright (c) 2015年 cd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


- (void) clickAnnViewBlock:(void (^)()) sender;

@end

