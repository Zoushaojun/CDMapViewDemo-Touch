//
//  MyAnnotationView.h
//  橙电
//
//  Created by 邹少军 on 15/10/20.
//  Copyright (c) 2015年 com.chengdian. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
#import "ViewController.h"


@interface MyAnnotationView : MKAnnotationView<MKAnnotation>
{
    UIButton *label;
}


- (void) setClusterText: (NSString *)text;

@property (nonatomic ,readonly) CLLocationCoordinate2D coordinate;

@end
