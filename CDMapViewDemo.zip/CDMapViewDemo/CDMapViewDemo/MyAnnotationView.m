//
//  MyAnnotationView.m
//  橙电
//
//  Created by 邹少军 on 15/10/20.
//  Copyright (c) 2015年 com.chengdian. All rights reserved.
//

#import "MyAnnotationView.h"

@implementation MyAnnotationView
@synthesize coordinate;

- (id) initWithAnnotation:(id<MKAnnotation>)annotation reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithAnnotation:annotation reuseIdentifier:reuseIdentifier];
    if ( self )
    {
        
//        label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 26, 26)];
//        [self addSubview:label];
//        label.textColor = [UIColor whiteColor];
//        label.backgroundColor = [UIColor clearColor];
//        label.font = [UIFont boldSystemFontOfSize:11];
//        label.textAlignment = NSTextAlignmentCenter;
//        label.shadowColor = [UIColor blackColor];
//        label.shadowOffset = CGSizeMake(0,-1);
        label = [UIButton buttonWithType:UIButtonTypeCustom];
        [label setFrame:CGRectMake(0, 0, 26, 26)];
        [label.titleLabel setTextColor:[UIColor whiteColor]];
        [label.titleLabel setFont:[UIFont boldSystemFontOfSize:11.0]];
        [label setBackgroundColor:[UIColor clearColor]];
        [label addTarget:self action:@selector(selectedButton:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:label];
    }
    return self;
}

- (void) setClusterText:(NSString *)text
{
    NSLog(@"text=%@",text);
    [label setTitle:text forState:UIControlStateNormal];
}

- (void)selectedButton:(UIButton *)sender
{
    ViewController *viewC = [[ViewController alloc] init];
    
    [viewC clickAnnViewBlock:^{
    
        
    }];
    
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
