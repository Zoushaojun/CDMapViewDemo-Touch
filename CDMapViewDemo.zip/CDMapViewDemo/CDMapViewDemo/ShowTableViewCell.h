//
//  ShowTableViewCell.h
//  CDMapViewDemo
//
//  Created by 邹少军 on 16/4/11.
//  Copyright © 2016年 cd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REVClusterPin.h"

@interface ShowTableViewCell : UITableViewCell


- (void)reloadingPin:(REVClusterPin *)Pin;

@end
