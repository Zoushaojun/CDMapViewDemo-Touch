//
//  main.m
//  CDMapViewDemo
//
//  Created by 邹少军 on 15/10/21.
//  Copyright (c) 2015年 cd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CDAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CDAppDelegate class]));
    }
}
